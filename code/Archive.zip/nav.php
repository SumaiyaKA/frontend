<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="style.css">
  <title>Harbour Space</title>
</head>
<body>
  <!-- navigation -->
  <header>
    <nav>
      <ul>
        <li><a href="index.php">HarbourSpace</a></li>
        <?php
            // don't show any error
            error_reporting(0);

        ?>
      </ul>
    </nav>
  </header>
</body>
</html>